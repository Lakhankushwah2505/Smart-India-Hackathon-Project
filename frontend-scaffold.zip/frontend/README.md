# Polar station energy dashboard — frontend

React (Vite) dashboard for the AI-driven smart energy management system
(SIH 2026, Problem Statement 26061).

## Stack

- React 18 + Vite
- React Router for navigation
- TanStack React Query for data fetching/polling
- Recharts for charts
- Axios for API calls
- Lucide for icons

## Getting started

```bash
npm install
cp .env.example .env
npm run dev
```

The app runs at `http://localhost:5173`. It works standalone with mock
data if the backend isn't running yet — see `src/services/*.js`, each
service falls back to mock data when the API call fails.

## Project structure

```
src/
├── components/
│   ├── alerts/        # Active alerts panel, history table
│   ├── dashboard/      # Metric cards, charts, status header
│   └── layout/          # Sidebar, page layout
├── pages/               # Dashboard, Forecasts, Alerts, Settings
├── services/            # API calls per domain (energy, forecast, alerts)
├── hooks/                # React Query hooks wrapping services
├── context/              # Global dashboard state
├── utils/                # Formatters, constants
└── styles/                # Global CSS + design tokens
```

## Connecting to the backend

Set `VITE_API_BASE_URL` in `.env` to point at your FastAPI/Flask backend.
Expected endpoints:

- `GET /energy/state` — battery SoC, diesel days remaining, solar/wind kW
- `GET /forecast/load` — array of `{ hour, forecastKw, actualKw }`
- `GET /alerts/active` — array of `{ id, severity, message }`
- `GET /alerts/history` — array of `{ id, timestamp, type, severity, detail, resolution }`
