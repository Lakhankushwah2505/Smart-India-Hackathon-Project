import { Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Forecasts from "./pages/Forecasts";
import Alerts from "./pages/Alerts";
import Settings from "./pages/Settings";

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/forecasts" element={<Forecasts />} />
      <Route path="/alerts" element={<Alerts />} />
      <Route path="/settings" element={<Settings />} />
    </Routes>
  );
}
