import { format } from "date-fns";

export function formatPercent(value) {
  return `${Math.round(value)}%`;
}

export function formatKw(value) {
  return `${value.toFixed(1)} kW`;
}

export function formatDays(value) {
  return `${Math.round(value)} days`;
}

export function formatTimestamp(isoString) {
  return format(new Date(isoString), "yyyy-MM-dd HH:mm");
}
