export const SAFETY_THRESHOLDS = {
  batterySocMin: 20, // percent, hard floor before forced diesel
  dieselDaysWarning: 14 // warn when remaining fuel days drop below this
};

export const ALERT_SEVERITY = {
  INFO: "info",
  WARNING: "warning",
  CRITICAL: "critical"
};

export const REFRESH_INTERVAL_MS = 60_000; // poll energy state every 60s

export const NAV_ITEMS = [
  { label: "Dashboard", path: "/" },
  { label: "Forecasts", path: "/forecasts" },
  { label: "Alerts", path: "/alerts" },
  { label: "Settings", path: "/settings" }
];
