import PageLayout from "./components/layout/PageLayout";
import AppRoutes from "./routes";

export default function App() {
  return (
    <PageLayout>
      <AppRoutes />
    </PageLayout>
  );
}
