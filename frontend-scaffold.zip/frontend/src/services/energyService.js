import { api } from "./api";

const MOCK_ENERGY_STATE = {
  batterySoc: 68,
  dieselDaysRemaining: 54,
  solarKw: 2.1,
  windKw: 3.4,
  status: "nominal",
  flow24h: [40, 65, 80, 55, 30, 70, 45] // percent scale, for the flow chart
};

export async function getEnergyState() {
  try {
    const { data } = await api.get("/energy/state");
    return data;
  } catch (err) {
    // Backend not ready yet — fall back to mock data so the UI still works
    return MOCK_ENERGY_STATE;
  }
}
