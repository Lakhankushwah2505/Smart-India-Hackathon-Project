import { api } from "./api";
import { ALERT_SEVERITY } from "../utils/constants";

const MOCK_ACTIVE_ALERTS = [
  {
    id: "a1",
    severity: ALERT_SEVERITY.INFO,
    message: "Battery reserve above safety threshold"
  },
  {
    id: "a2",
    severity: ALERT_SEVERITY.WARNING,
    message: "Wind forecast running 12% below actual this week"
  },
  {
    id: "a3",
    severity: ALERT_SEVERITY.INFO,
    message: "Diesel generator run-hours: 412, next service in 88h"
  }
];

const MOCK_HISTORY = [
  {
    id: "h1",
    timestamp: "2026-07-14T03:00:00Z",
    type: "Safety override",
    severity: ALERT_SEVERITY.CRITICAL,
    detail: "Forced diesel on — battery SoC projected below 20%",
    resolution: "Resolved — SoC recovered above threshold"
  },
  {
    id: "h2",
    timestamp: "2026-07-13T18:20:00Z",
    type: "Forecast drift",
    severity: ALERT_SEVERITY.WARNING,
    detail: "Wind forecast error exceeded 10% for 3 consecutive cycles",
    resolution: "Safety margin widened automatically"
  },
  {
    id: "h3",
    timestamp: "2026-07-12T09:05:00Z",
    type: "Maintenance",
    severity: ALERT_SEVERITY.INFO,
    detail: "Diesel generator reached 400 run-hours",
    resolution: "Service scheduled"
  }
];

export async function getActiveAlerts() {
  try {
    const { data } = await api.get("/alerts/active");
    return data;
  } catch (err) {
    return MOCK_ACTIVE_ALERTS;
  }
}

export async function getAlertHistory(filters = {}) {
  try {
    const { data } = await api.get("/alerts/history", { params: filters });
    return data;
  } catch (err) {
    return MOCK_HISTORY;
  }
}
