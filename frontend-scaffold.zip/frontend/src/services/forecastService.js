import { api } from "./api";

const MOCK_FORECAST = Array.from({ length: 24 }, (_, hour) => ({
  hour,
  forecastKw: 3 + Math.sin(hour / 3) * 1.5,
  actualKw: 3 + Math.sin(hour / 3) * 1.5 + (Math.random() - 0.5) * 0.8
}));

export async function getForecastVsActual() {
  try {
    const { data } = await api.get("/forecast/load");
    return data;
  } catch (err) {
    return MOCK_FORECAST;
  }
}
