import { LineChart, Line, ResponsiveContainer, XAxis, Tooltip, Legend } from "recharts";

export default function ForecastChart({ data = [] }) {
  return (
    <div className="card">
      <p style={{ fontSize: 14, fontWeight: 500, margin: "0 0 12px" }}>
        Forecast vs actual load
      </p>
      <div style={{ height: 140 }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <XAxis dataKey="hour" hide />
            <Tooltip />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Line
              type="monotone"
              dataKey="forecastKw"
              name="Forecast"
              stroke="#888780"
              strokeDasharray="4 3"
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="actualKw"
              name="Actual"
              stroke="#0F6E56"
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
