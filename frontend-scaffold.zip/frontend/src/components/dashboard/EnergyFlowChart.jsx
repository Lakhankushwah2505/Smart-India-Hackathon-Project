import { BarChart, Bar, ResponsiveContainer, XAxis, Tooltip } from "recharts";

export default function EnergyFlowChart({ data = [] }) {
  const chartData = data.map((value, index) => ({ hour: index, value }));

  return (
    <div className="card">
      <p style={{ fontSize: 14, fontWeight: 500, margin: "0 0 12px" }}>
        Energy flow, last 24h
      </p>
      <div style={{ height: 140 }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <XAxis dataKey="hour" hide />
            <Tooltip />
            <Bar dataKey="value" fill="#5DCAA5" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
