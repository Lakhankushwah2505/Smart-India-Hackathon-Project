import { useDashboard } from "../../context/DashboardContext";

export default function StatusHeader({ status = "nominal", updatedAgo = "2 min ago" }) {
  const { stationName } = useDashboard();

  const badgeStyle =
    status === "nominal"
      ? { background: "var(--success-bg)", color: "var(--success)" }
      : status === "warning"
      ? { background: "var(--warning-bg)", color: "var(--warning)" }
      : { background: "var(--danger-bg)", color: "var(--danger)" };

  const label =
    status === "nominal"
      ? "All systems nominal"
      : status === "warning"
      ? "Attention needed"
      : "Critical alert";

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: "1rem"
      }}
    >
      <div>
        <p style={{ fontWeight: 500, fontSize: 16, margin: 0 }}>
          {stationName} — energy overview
        </p>
        <p style={{ fontSize: 13, color: "var(--text-secondary)", margin: "2px 0 0" }}>
          Last updated {updatedAgo}
        </p>
      </div>
      <span
        style={{
          fontSize: 12,
          padding: "4px 12px",
          borderRadius: "var(--radius)",
          ...badgeStyle
        }}
      >
        {label}
      </span>
    </div>
  );
}
