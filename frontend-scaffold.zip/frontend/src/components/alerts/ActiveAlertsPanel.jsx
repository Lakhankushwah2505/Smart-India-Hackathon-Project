import { Check, AlertTriangle, Clock } from "lucide-react";
import { ALERT_SEVERITY } from "../../utils/constants";

function iconFor(severity) {
  if (severity === ALERT_SEVERITY.CRITICAL || severity === ALERT_SEVERITY.WARNING) {
    return <AlertTriangle size={16} color="var(--warning)" />;
  }
  if (severity === ALERT_SEVERITY.INFO) {
    return <Clock size={16} color="var(--text-secondary)" />;
  }
  return <Check size={16} color="var(--success)" />;
}

export default function ActiveAlertsPanel({ alerts = [] }) {
  return (
    <div className="card">
      <p style={{ fontSize: 14, fontWeight: 500, margin: "0 0 12px" }}>
        Active alerts
      </p>
      {alerts.map((alert, index) => (
        <div
          key={alert.id}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            padding: "8px 0",
            borderBottom:
              index < alerts.length - 1 ? "0.5px solid var(--border)" : "none"
          }}
        >
          {iconFor(alert.severity)}
          <p style={{ fontSize: 13, margin: 0 }}>{alert.message}</p>
        </div>
      ))}
      {alerts.length === 0 && (
        <p style={{ fontSize: 13, color: "var(--text-secondary)" }}>
          No active alerts.
        </p>
      )}
    </div>
  );
}
