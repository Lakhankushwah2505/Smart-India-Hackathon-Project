import { formatTimestamp } from "../../utils/formatters";

export default function AlertHistoryTable({ history = [] }) {
  return (
    <div className="card" style={{ marginTop: 12 }}>
      <p style={{ fontSize: 14, fontWeight: 500, margin: "0 0 12px" }}>
        History log
      </p>
      <table style={{ width: "100%", fontSize: 13, borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ textAlign: "left", color: "var(--text-secondary)" }}>
            <th style={{ padding: "6px 8px 6px 0", fontWeight: 500 }}>Time</th>
            <th style={{ padding: "6px 8px", fontWeight: 500 }}>Type</th>
            <th style={{ padding: "6px 8px", fontWeight: 500 }}>Detail</th>
            <th style={{ padding: "6px 0 6px 8px", fontWeight: 500 }}>Resolution</th>
          </tr>
        </thead>
        <tbody>
          {history.map((row) => (
            <tr key={row.id} style={{ borderTop: "0.5px solid var(--border)" }}>
              <td style={{ padding: "8px 8px 8px 0", whiteSpace: "nowrap" }}>
                {formatTimestamp(row.timestamp)}
              </td>
              <td style={{ padding: "8px" }}>{row.type}</td>
              <td style={{ padding: "8px" }}>{row.detail}</td>
              <td style={{ padding: "8px 0 8px 8px" }}>{row.resolution}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {history.length === 0 && (
        <p style={{ fontSize: 13, color: "var(--text-secondary)" }}>
          No history yet.
        </p>
      )}
    </div>
  );
}
