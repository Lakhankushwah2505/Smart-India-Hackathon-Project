import { NavLink } from "react-router-dom";
import { NAV_ITEMS } from "../../utils/constants";

export default function Sidebar() {
  return (
    <nav
      style={{
        width: 200,
        borderRight: "0.5px solid var(--border)",
        padding: "1.5rem 1rem"
      }}
    >
      <p style={{ fontWeight: 500, fontSize: 15, marginBottom: "1.5rem" }}>
        Energy control
      </p>
      <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
        {NAV_ITEMS.map((item) => (
          <li key={item.path} style={{ marginBottom: 8 }}>
            <NavLink
              to={item.path}
              style={({ isActive }) => ({
                display: "block",
                padding: "8px 10px",
                borderRadius: "var(--radius)",
                fontSize: 14,
                textDecoration: "none",
                color: isActive ? "var(--accent-text)" : "var(--text-primary)",
                background: isActive ? "var(--accent-bg)" : "transparent"
              })}
            >
              {item.label}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}
