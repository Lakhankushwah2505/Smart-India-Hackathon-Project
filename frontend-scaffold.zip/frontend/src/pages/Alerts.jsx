import { useState } from "react";
import ActiveAlertsPanel from "../components/alerts/ActiveAlertsPanel";
import AlertHistoryTable from "../components/alerts/AlertHistoryTable";
import { useActiveAlerts, useAlertHistory } from "../hooks/useAlerts";

export default function Alerts() {
  const [filters] = useState({});
  const { data: activeAlerts } = useActiveAlerts();
  const { data: history, isLoading } = useAlertHistory(filters);

  return (
    <div>
      <p style={{ fontWeight: 500, fontSize: 16, marginBottom: 16 }}>
        Alerts and history
      </p>
      <ActiveAlertsPanel alerts={activeAlerts || []} />
      {isLoading ? (
        <p style={{ color: "var(--text-secondary)", marginTop: 12 }}>
          Loading history…
        </p>
      ) : (
        <AlertHistoryTable history={history || []} />
      )}
    </div>
  );
}
