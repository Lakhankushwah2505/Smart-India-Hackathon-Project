import { useState } from "react";
import { SAFETY_THRESHOLDS } from "../utils/constants";

export default function Settings() {
  const [batteryMin, setBatteryMin] = useState(SAFETY_THRESHOLDS.batterySocMin);
  const [dieselWarning, setDieselWarning] = useState(SAFETY_THRESHOLDS.dieselDaysWarning);

  return (
    <div>
      <p style={{ fontWeight: 500, fontSize: 16, marginBottom: 16 }}>
        Safety thresholds
      </p>
      <div className="card" style={{ maxWidth: 400 }}>
        <label style={{ display: "block", fontSize: 13, marginBottom: 6 }}>
          Minimum battery reserve (%)
        </label>
        <input
          type="number"
          value={batteryMin}
          onChange={(e) => setBatteryMin(Number(e.target.value))}
          style={{ width: "100%", marginBottom: 16 }}
        />
        <label style={{ display: "block", fontSize: 13, marginBottom: 6 }}>
          Diesel warning threshold (days)
        </label>
        <input
          type="number"
          value={dieselWarning}
          onChange={(e) => setDieselWarning(Number(e.target.value))}
          style={{ width: "100%" }}
        />
      </div>
    </div>
  );
}
