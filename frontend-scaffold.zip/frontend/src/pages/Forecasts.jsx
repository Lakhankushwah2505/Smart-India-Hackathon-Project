import ForecastChart from "../components/dashboard/ForecastChart";
import { useForecastData } from "../hooks/useForecastData";

export default function Forecasts() {
  const { data: forecast, isLoading } = useForecastData();

  return (
    <div>
      <p style={{ fontWeight: 500, fontSize: 16, marginBottom: 16 }}>
        Forecast detail
      </p>
      {isLoading ? (
        <p style={{ color: "var(--text-secondary)" }}>Loading forecast…</p>
      ) : (
        <ForecastChart data={forecast || []} />
      )}
    </div>
  );
}
