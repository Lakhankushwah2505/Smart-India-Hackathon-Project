import StatusHeader from "../components/dashboard/StatusHeader";
import MetricCard from "../components/dashboard/MetricCard";
import EnergyFlowChart from "../components/dashboard/EnergyFlowChart";
import ForecastChart from "../components/dashboard/ForecastChart";
import ActiveAlertsPanel from "../components/alerts/ActiveAlertsPanel";
import { useEnergyData } from "../hooks/useEnergyData";
import { useForecastData } from "../hooks/useForecastData";
import { useActiveAlerts } from "../hooks/useAlerts";
import { formatPercent, formatKw, formatDays } from "../utils/formatters";

export default function Dashboard() {
  const { data: energy, isLoading: loadingEnergy } = useEnergyData();
  const { data: forecast } = useForecastData();
  const { data: alerts } = useActiveAlerts();

  if (loadingEnergy || !energy) {
    return <p style={{ color: "var(--text-secondary)" }}>Loading energy state…</p>;
  }

  return (
    <div>
      <StatusHeader status={energy.status} />

      <div className="grid-metrics">
        <MetricCard label="Battery SoC" value={formatPercent(energy.batterySoc)} />
        <MetricCard label="Diesel remaining" value={formatDays(energy.dieselDaysRemaining)} />
        <MetricCard label="Solar output" value={formatKw(energy.solarKw)} />
        <MetricCard label="Wind output" value={formatKw(energy.windKw)} />
      </div>

      <div className="grid-two-col">
        <EnergyFlowChart data={energy.flow24h} />
        <ForecastChart data={forecast || []} />
      </div>

      <ActiveAlertsPanel alerts={alerts || []} />
    </div>
  );
}
