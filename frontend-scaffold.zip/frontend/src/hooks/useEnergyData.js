import { useQuery } from "@tanstack/react-query";
import { getEnergyState } from "../services/energyService";
import { REFRESH_INTERVAL_MS } from "../utils/constants";

export function useEnergyData() {
  return useQuery({
    queryKey: ["energyState"],
    queryFn: getEnergyState,
    refetchInterval: REFRESH_INTERVAL_MS
  });
}
