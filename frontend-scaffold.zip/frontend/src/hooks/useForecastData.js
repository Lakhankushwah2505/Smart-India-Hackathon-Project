import { useQuery } from "@tanstack/react-query";
import { getForecastVsActual } from "../services/forecastService";

export function useForecastData() {
  return useQuery({
    queryKey: ["forecastVsActual"],
    queryFn: getForecastVsActual
  });
}
