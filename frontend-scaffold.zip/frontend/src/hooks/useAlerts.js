import { useQuery } from "@tanstack/react-query";
import { getActiveAlerts, getAlertHistory } from "../services/alertService";
import { REFRESH_INTERVAL_MS } from "../utils/constants";

export function useActiveAlerts() {
  return useQuery({
    queryKey: ["activeAlerts"],
    queryFn: getActiveAlerts,
    refetchInterval: REFRESH_INTERVAL_MS
  });
}

export function useAlertHistory(filters) {
  return useQuery({
    queryKey: ["alertHistory", filters],
    queryFn: () => getAlertHistory(filters)
  });
}
